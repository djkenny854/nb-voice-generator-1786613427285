import React, { useState } from 'react';
import { Container, Row, Col, Card, Form, Button, Table } from 'react-bootstrap';
import { FaPlus, FaTrash, FaDownload } from 'react-icons/fa';
import jsPDF from 'jspdf';
import html2canvas from 'html2canvas';

function App() {
  const [invoice, setInvoice] = useState({
    invoiceNumber: 'INV-' + Math.floor(100000 + Math.random() * 900000),
    createdDate: new Date().toISOString().substring(0, 10),
    dueDate: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString().substring(0, 10),
    senderName: '',
    senderEmail: '',
    senderAddress: '',
    clientName: '',
    clientEmail: '',
    clientAddress: '',
    items: [{ id: 1, description: '', quantity: 1, price: 0 }],
    notes: 'Thank you for your business!',
    taxRate: 0,
    discount: 0,
  });

  const handleInvoiceChange = (e) => {
    const { name, value } = e.target;
    setInvoice((prev) => ({ ...prev, [name]: value }));
  };

  const handleItemChange = (id, field, value) => {
    setInvoice((prev) => ({
      ...prev,
      items: prev.items.map((item) => {
        if (item.id === id) {
          return { ...item, [field]: value };
        }
        return item;
      }),
    }));
  };

  const addItem = () => {
    setInvoice((prev) => ({
      ...prev,
      items: [...prev.items, { id: Date.now(), description: '', quantity: 1, price: 0 }],
    }));
  };

  const removeItem = (id) => {
    setInvoice((prev) => ({
      ...prev,
      items: prev.items.filter((item) => item.id !== id),
    }));
  };

  const calculateSubtotal = () => {
    return invoice.items.reduce((acc, item) => acc + (item.quantity * item.price || 0), 0);
  };

  const calculateTax = () => {
    return calculateSubtotal() * (invoice.taxRate / 100);
  };

  const calculateTotal = () => {
    return calculateSubtotal() + calculateTax() - (invoice.discount || 0);
  };

  const downloadPDF = () => {
    const element = document.getElementById('invoice-preview');
    if (!element) return;
    html2canvas(element, { scale: 2 }).then((canvas) => {
      const imgData = canvas.toDataURL('image/png');
      const pdf = new jsPDF('p', 'mm', 'a4');
      const imgWidth = 210;
      const pageHeight = 295;
      const imgHeight = (canvas.height * imgWidth) / canvas.width;
      let heightLeft = imgHeight;
      let position = 0;

      pdf.addImage(imgData, 'PNG', 0, position, imgWidth, imgHeight);
      heightLeft -= pageHeight;

      while (heightLeft >= 0) {
        position = heightLeft - imgHeight;
        pdf.addPage();
        pdf.addImage(imgData, 'PNG', 0, position, imgWidth, imgHeight);
        heightLeft -= pageHeight;
      }
      pdf.save(`${invoice.invoiceNumber}.pdf`);
    });
  };

  return (
    <Container className="my-5">
      <h1 className="text-center mb-4">Invoice Generator</h1>
      <Row>
        <Col md={6}>
          <Card className="p-4 shadow-sm mb-4">
            <h4 className="mb-3">Invoice Details</h4>
            <Form>
              <Row>
                <Col md={6}>
                  <Form.Group className="mb-3">
                    <Form.Label>Invoice Number</Form.Label>
                    <Form.Control
                      type="text"
                      name="invoiceNumber"
                      value={invoice.invoiceNumber}
                      onChange={handleInvoiceChange}
                    />
                  </Form.Group>
                </Col>
                <Col md={6}>
                  <Form.Group className="mb-3">
                    <Form.Label>Created Date</Form.Label>
                    <Form.Control
                      type="date"
                      name="createdDate"
                      value={invoice.createdDate}
                      onChange={handleInvoiceChange}
                    />
                  </Form.Group>
                </Col>
                <Col md={6}>
                  <Form.Group className="mb-3">
                    <Form.Label>Due Date</Form.Label>
                    <Form.Control
                      type="date"
                      name="dueDate"
                      value={invoice.dueDate}
                      onChange={handleInvoiceChange}
                    />
                  </Form.Group>
                </Col>
              </Row>

              <hr />
              <h5 className="mb-3">From (Sender)</h5>
              <Form.Group className="mb-3">
                <Form.Label>Sender Name</Form.Label>
                <Form.Control
                  type="text"
                  name="senderName"
                  value={invoice.senderName}
                  onChange={handleInvoiceChange}
                  placeholder="Your Business / Name"
                />
              </Form.Group>
              <Form.Group className="mb-3">
                <Form.Label>Sender Email</Form.Label>
                <Form.Control
                  type="email"
                  name="senderEmail"
                  value={invoice.senderEmail}
                  onChange={handleInvoiceChange}
                  placeholder="sender@example.com"
                />
              </Form.Group>
              <Form.Group className="mb-3">
                <Form.Label>Sender Address</Form.Label>
                <Form.Control
                  as="textarea"
                  rows={2}
                  name="senderAddress"
                  value={invoice.senderAddress}
                  onChange={handleInvoiceChange}
                  placeholder="123 Street, City, Country"
                />
              </Form.Group>

              <hr />
              <h5 className="mb-3">Bill To (Client)</h5>
              <Form.Group className="mb-3">
                <Form.Label>Client Name</Form.Label>
                <Form.Control
                  type="text"
                  name="clientName"
                  value={invoice.clientName}
                  onChange={handleInvoiceChange}
                  placeholder="Client Business / Name"
                />
              </Form.Group>
              <Form.Group className="mb-3">
                <Form.Label>Client Email</Form.Label>
                <Form.Control
                  type="email"
                  name="clientEmail"
                  value={invoice.clientEmail}
                  onChange={handleInvoiceChange}
                  placeholder="client@example.com"
                />
              </Form.Group>
              <Form.Group className="mb-3">
                <Form.Label>Client Address</Form.Label>
                <Form.Control
                  as="textarea"
                  rows={2}
                  name="clientAddress"
                  value={invoice.clientAddress}
                  onChange={handleInvoiceChange}
                  placeholder="456 Street, City, Country"
                />
              </Form.Group>
            </Form>
          </Card>
        </Col>

        <Col md={6}>
          <Card className="p-4 shadow-sm mb-4">
            <h4 className="mb-3">Line Items</h4>
            <Table responsive>
              <thead>
                <tr>
                  <th>Description</th>
                  <th style={{ width: '80px' }}>Qty</th>
                  <th style={{ width: '120px' }}>Price</th>
                  <th style={{ width: '40px' }}></th>
                </tr>
              </thead>
              <tbody>
                {invoice.items.map((item) => (
                  <tr key={item.id}>
                    <td>
                      <Form.Control
                        type="text"
                        placeholder="Item description"
                        value={item.description}
                        onChange={(e) => handleItemChange(item.id, 'description', e.target.value)}
                      />
                    </td>
                    <td>
                      <Form.Control
                        type="number"
                        min="1"
                        value={item.quantity}
                        onChange={(e) => handleItemChange(item.id, 'quantity', parseInt(e.target.value) || 0)}
                      />
                    </td>
                    <td>
                      <Form.Control
                        type="number"
                        step="0.01"
                        min="0"
                        value={item.price}
                        onChange={(e) => handleItemChange(item.id, 'price', parseFloat(e.target.value) || 0)}
                      />
                    </td>
                    <td>
                      <Button variant="outline-danger" size="sm" onClick={() => removeItem(item.id)}>
                        <FaTrash />
                      </Button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </Table>
            <Button variant="outline-primary" className="mb-3" onClick={addItem}>
              <FaPlus className="me-2" /> Add Item
            </Button>

            <Row className="mt-3">
              <Col md={6}>
                <Form.Group className="mb-3">
                  <Form.Label>Tax Rate (%)</Form.Label>
                  <Form.Control
                    type="number"
                    min="0"
                    name="taxRate"
                    value={invoice.taxRate}
                    onChange={handleInvoiceChange}
                  />
                </Form.Group>
              </Col>
              <Col md={6}>
                <Form.Group className="mb-3">
                  <Form.Label>Discount ($)</Form.Label>
                  <Form.Control
                    type="number"
                    min="0"
                    name="discount"
                    value={invoice.discount}
                    onChange={handleInvoiceChange}
                  />
                </Form.Group>
              </Col>
            </Row>

            <Form.Group className="mb-3">
              <Form.Label>Notes</Form.Label>
              <Form.Control
                as="textarea"
                rows={2}
                name="notes"
                value={invoice.notes}
                onChange={handleInvoiceChange}
              />
            </Form.Group>
          </Card>
        </Col>
      </Row>

      <Row className="justify-content-center">
        <Col md={8}>
          <Card className="p-5 shadow-sm mb-4" id="invoice-preview" style={{ backgroundColor: '#fff', color: '#333' }}>
            <div className="d-flex justify-content-between align-items-start mb-4">
              <div>
                <h2>{invoice.senderName || 'Sender Name'}</h2>
                <p className="text-muted mb-0">{invoice.senderEmail}</p>
                <p className="text-muted mb-0">{invoice.senderAddress}</p>
              </div>
              <div className="text-end">
                <h1 className="text-primary">INVOICE</h1>
                <h5>#{invoice.invoiceNumber}</h5>
                <p className="mb-0"><strong>Date:</strong> {invoice.createdDate}</p>
                <p className="mb-0"><strong>Due Date:</strong> {invoice.dueDate}</p>
              </div>
            </div>

            <hr />

            <div className="mb-4">
              <h6><strong>BILL TO:</strong></h6>
              <h5>{invoice.clientName || 'Client Name'}</h5>
              <p className="text-muted mb-0">{invoice.clientEmail}</p>
              <p className="text-muted mb-0">{invoice.clientAddress}</p>
            </div>

            <Table striped bordered hover className="mb-4">
              <thead>
                <tr>
                  <th>Description</th>
                  <th className="text-center">Qty</th>
                  <th className="text-end">Price</th>
                  <th className="text-end">Amount</th>
                </tr>
              </thead>
              <tbody>
                {invoice.items.map((item) => (
                  <tr key={item.id}>
                    <td>{item.description || 'Untitled Item'}</td>
                    <td className="text-center">{item.quantity}</td>
                    <td className="text-end">${(item.price || 0).toFixed(2)}</td>
                    <td className="text-end">${((item.quantity || 0) * (item.price || 0)).toFixed(2)}</td>
                  </tr>
                ))}
              </tbody>
            </Table>

            <div className="d-flex justify-content-end mb-4">
              <div style={{ width: '250px' }}>
                <div className="d-flex justify-content-between py-1">
                  <span>Subtotal:</span>
                  <span>${calculateSubtotal().toFixed(2)}</span>
                </div>
                {invoice.taxRate > 0 && (
                  <div className="d-flex justify-content-between py-1">
                    <span>Tax ({invoice.taxRate}%):</span>
                    <span>${calculateTax().toFixed(2)}</span>
                  </div>
                )}
                {invoice.discount > 0 && (
                  <div className="d-flex justify-content-between py-1 text-danger">
                    <span>Discount:</span>
                    <span>-${parseFloat(invoice.discount).toFixed(2)}</span>
                  </div>
                )}
                <hr className="my-1" />
                <div className="d-flex justify-content-between py-2 fw-bold h5">
                  <span>Total:</span>
                  <span className="text-primary">${calculateTotal().toFixed(2)}</span>
                </div>
              </div>
            </div>

            {invoice.notes && (
              <div>
                <hr />
                <h6><strong>Notes:</strong></h6>
                <p className="text-muted mb-0">{invoice.notes}</p>
              </div>
            )}
          </Card>
          <div className="text-center">
            <Button variant="success" size="lg" onClick={downloadPDF}>
              <FaDownload className="me-2" /> Download Invoice PDF
            </Button>
          </div>
        </Col>
      </Row>
    </Container>
  );
}

export default App;