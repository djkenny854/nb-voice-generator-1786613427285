# Canonical project (NativeForge CPR)

This archive is machine generated. It is the canonical representation of the
uploaded source: framework **React**, build tool **Create React App**,
Platform release **2026.08**, Node **24**, Capacitor **7.4.3**.

The build pipeline consumes this archive only. The original upload is preserved
untouched under `original/source.zip`.
